﻿
namespace Enumerations
{
        public enum TerrainType: short
        {
            City,
            Beach,
            Mountain,
            AllTerrain
        }
}
